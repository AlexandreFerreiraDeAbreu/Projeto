(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"modeloEscalas_atlas_", frames: [[528,3299,87,96],[0,786,1331,784],[0,1572,1331,784],[1199,2740,331,178],[1075,2988,331,178],[327,2713,434,181],[1009,3168,119,120],[0,0,1331,784],[0,3072,1073,63],[122,3326,59,88],[183,3326,59,88],[0,3326,59,88],[61,3326,59,88],[1130,3168,84,131],[359,3137,167,168],[528,3137,160,160],[0,2713,325,357],[852,3137,155,156],[1120,2358,378,380],[763,2740,434,181],[189,3137,168,169],[0,3137,187,187],[327,2923,1055,63],[0,2567,1118,144],[0,2358,1118,207],[690,3137,160,160]]}
];


// symbols:



(lib.assinalaBT = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.backgroundEscalas = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.backgroundEscalas2 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.bt_6x6 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.bt_medio = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.computer = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.creditosBT = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CópiadebackgroundSQ = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Cópiadetitulo2 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.flash0ai = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.flash0ai_1 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.flash0ai_2 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.flash0ai_3 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.flash0ai_4 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.fullscreenBT1 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.infoBT = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.monster_2 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.novoLogin = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.playBT = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.player_1 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.retmenuBT = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.square_2 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.titulo = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.titulo3 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.titulo5 = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.topBT = function() {
	this.spriteSheet = ss["modeloEscalas_atlas_"];
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Símbolo1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Camada_1
	this.instance = new lib.titulo3();
	this.instance.parent = this;
	this.instance.setTransform(-310.5,-40,0.556,0.556);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Símbolo1, new cjs.Rectangle(-310.5,-40,621.1,80), null);


// stage content:
(lib.modeloEscalas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Camada_1
	this.instance = new lib.Cópiadetitulo2();
	this.instance.parent = this;
	this.instance.setTransform(89,25,0.841,0.841);

	this.instance_1 = new lib.titulo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(119,-139,0.794,0.794);

	this.instance_2 = new lib.titulo();
	this.instance_2.parent = this;
	this.instance_2.setTransform(118,29,0.001,0.016);

	this.instance_3 = new lib.novoLogin();
	this.instance_3.parent = this;
	this.instance_3.setTransform(929,325,0.513,0.513);

	this.instance_4 = new lib.fullscreenBT1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(15,12,0.416,0.417);

	this.instance_5 = new lib.playBT();
	this.instance_5.parent = this;
	this.instance_5.setTransform(398,222,0.605,0.605);

	this.instance_6 = new lib.topBT();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1148,218,0.5,0.5);

	this.instance_7 = new lib.creditosBT();
	this.instance_7.parent = this;
	this.instance_7.setTransform(929,503,0.667,0.667);

	this.instance_8 = new lib.infoBT();
	this.instance_8.parent = this;
	this.instance_8.setTransform(929,414,0.5,0.5);

	this.instance_9 = new lib.backgroundEscalas();
	this.instance_9.parent = this;
	this.instance_9.setTransform(9,728,0.769,0.765);

	this.instance_10 = new lib.backgroundEscalas2();
	this.instance_10.parent = this;
	this.instance_10.setTransform(3,2,0.765,0.761);

	this.instance_11 = new lib.retmenuBT();
	this.instance_11.parent = this;
	this.instance_11.setTransform(15,14,0.414,0.414);

	this.instance_12 = new lib.Símbolo1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(520.2,-136.6);
	this.instance_12.filters = [new cjs.ColorFilter(0, 0, 0, 1, 124, 65, 9, 0)];
	this.instance_12.cache(-312,-42,625,84);

	this.instance_13 = new lib.square_2();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-264,206);

	this.instance_14 = new lib.titulo5();
	this.instance_14.parent = this;
	this.instance_14.setTransform(242,55,0.483,0.483);

	this.instance_15 = new lib.square_2();
	this.instance_15.parent = this;
	this.instance_15.setTransform(609,447.6,0.362,0.362);

	this.instance_16 = new lib.square_2();
	this.instance_16.parent = this;
	this.instance_16.setTransform(543.7,447.6,0.362,0.362);

	this.instance_17 = new lib.square_2();
	this.instance_17.parent = this;
	this.instance_17.setTransform(478.2,447.6,0.362,0.362);

	this.instance_18 = new lib.square_2();
	this.instance_18.parent = this;
	this.instance_18.setTransform(412.8,447.6,0.362,0.362);

	this.instance_19 = new lib.square_2();
	this.instance_19.parent = this;
	this.instance_19.setTransform(347.4,447.6,0.362,0.362);

	this.instance_20 = new lib.square_2();
	this.instance_20.parent = this;
	this.instance_20.setTransform(609,382.5,0.362,0.362);

	this.instance_21 = new lib.square_2();
	this.instance_21.parent = this;
	this.instance_21.setTransform(543.7,382.5,0.362,0.362);

	this.instance_22 = new lib.square_2();
	this.instance_22.parent = this;
	this.instance_22.setTransform(478.2,382.5,0.362,0.362);

	this.instance_23 = new lib.square_2();
	this.instance_23.parent = this;
	this.instance_23.setTransform(412.8,382.5,0.362,0.362);

	this.instance_24 = new lib.square_2();
	this.instance_24.parent = this;
	this.instance_24.setTransform(347.4,382.5,0.362,0.362);

	this.instance_25 = new lib.square_2();
	this.instance_25.parent = this;
	this.instance_25.setTransform(609,319.3,0.362,0.362);

	this.instance_26 = new lib.square_2();
	this.instance_26.parent = this;
	this.instance_26.setTransform(543.7,319.3,0.362,0.362);

	this.instance_27 = new lib.square_2();
	this.instance_27.parent = this;
	this.instance_27.setTransform(478.2,319.3,0.362,0.362);

	this.instance_28 = new lib.square_2();
	this.instance_28.parent = this;
	this.instance_28.setTransform(412.8,319.3,0.362,0.362);

	this.instance_29 = new lib.square_2();
	this.instance_29.parent = this;
	this.instance_29.setTransform(347.4,319.3,0.362,0.362);

	this.instance_30 = new lib.square_2();
	this.instance_30.parent = this;
	this.instance_30.setTransform(609,258.4,0.362,0.362);

	this.instance_31 = new lib.square_2();
	this.instance_31.parent = this;
	this.instance_31.setTransform(543.7,258.4,0.362,0.362);

	this.instance_32 = new lib.square_2();
	this.instance_32.parent = this;
	this.instance_32.setTransform(478.2,258.4,0.362,0.362);

	this.instance_33 = new lib.square_2();
	this.instance_33.parent = this;
	this.instance_33.setTransform(412.8,258.4,0.362,0.362);

	this.instance_34 = new lib.square_2();
	this.instance_34.parent = this;
	this.instance_34.setTransform(347.4,258.4,0.362,0.362);

	this.instance_35 = new lib.square_2();
	this.instance_35.parent = this;
	this.instance_35.setTransform(609,195.2,0.362,0.362);

	this.instance_36 = new lib.square_2();
	this.instance_36.parent = this;
	this.instance_36.setTransform(543.7,195.2,0.362,0.362);

	this.instance_37 = new lib.square_2();
	this.instance_37.parent = this;
	this.instance_37.setTransform(478.2,195.2,0.362,0.362);

	this.instance_38 = new lib.square_2();
	this.instance_38.parent = this;
	this.instance_38.setTransform(412.8,195.2,0.362,0.362);

	this.instance_39 = new lib.square_2();
	this.instance_39.parent = this;
	this.instance_39.setTransform(347.4,195.2,0.362,0.362);

	this.instance_40 = new lib.bt_medio();
	this.instance_40.parent = this;
	this.instance_40.setTransform(56,70,0.45,0.449);

	this.instance_41 = new lib.flash0ai();
	this.instance_41.parent = this;
	this.instance_41.setTransform(792,199,0.568,0.568);

	this.instance_42 = new lib.flash0ai_1();
	this.instance_42.parent = this;
	this.instance_42.setTransform(1122,225,0.569,0.568);

	this.instance_43 = new lib.flash0ai_2();
	this.instance_43.parent = this;
	this.instance_43.setTransform(1069,122,0.569,0.568);

	this.instance_44 = new lib.flash0ai_3();
	this.instance_44.parent = this;
	this.instance_44.setTransform(1149,317,0.569,0.568);

	this.instance_45 = new lib.flash0ai_4();
	this.instance_45.parent = this;
	this.instance_45.setTransform(1134,381,0.382,0.382);

	this.instance_46 = new lib.assinalaBT();
	this.instance_46.parent = this;
	this.instance_46.setTransform(1156,150,0.417,0.417);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DFD1DD").s().p("Ag3CZQgZgIgagVQgIgGgDgEQgEgFgBgDQAAgDACgDIAFgEQALgGAOABQAOABAKAFQAQAIAMADQANADAKgBQAKAAAIgEQAIgFAHgHQAHgHADgHQADgIABgGQAAgGgCgFQgCgGgDgCQgHgGgIgBQgIgBgNACQgQACgQgIQgRgJgLgRQgKgOAPgFQAjgLAZgMQAXgMAOgKQAPgKAEgJQAFgIgEgGQgDgEgGAAIgKACIgKAEIgMAGIgKAGQgHAGgKABQgJACgLgBQgKgBgJgEQgJgDgHgFQgNgMAKgMQAFgHAJgJQAJgIALgHQALgHAMgGQANgGAMgDIAVgDQALAAAMACQAMADANAIQANAHAMAPQANAQAFAPQAEAPgBAOQgBANgGAMQgGALgIAIQgLAJgOAIQgOAHgSAHIASAGQAIAEAHAGQAOALAGANQAHAMABAMQABAMgEAMQgFAMgIAKQgTAXgZAIQgYAIgdAAQgWAAgZgHg");
	this.shape.setTransform(955.6,302.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DFD1DD").s().p("AhKCeIgGgCIgFgEIgHgFIgIgHIgIgHIgHgHIgEgGIgDgGQgBgEACgDQABgEAEgDQATgOAVgTQAVgTAUgUQAUgTAQgTQARgUAMgRQAMgQAFgLQAFgLgFgDQgEgEgHACQgHACgIAGQgJAFgJAIIgRARQgHAFgIACQgJADgIAAQgJABgJgBQgJgCgIgDQgFgBgDgDQgDgCgBgEQgBgEACgHQACgGAFgJQARgdAZgTQAZgUAdgFQASgDAPADQAQADANAGQANAHAKAJQAKAJAGAJQAIANACAMQACAMgCAMQgCALgGAMQgGAMgIAMQgIAOgNAOQgNAQgQAPQgPAQgRAOQgRAPgPAMQAOgDAPgBIAcgCQAIAAAFADQAGADAFAGIAIAMIAFANQADAGgCACQgDACgIABIgeADIgiAEIggAEIgbAFIgNACIgIgBg");
	this.shape_1.setTransform(933.5,303.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DFD1DD").s().p("AhKCeIgGgCIgFgEIgHgFIgIgHIgIgHIgHgHIgEgGIgDgGQgBgEACgDQABgEAEgDQATgOAVgTQAVgTAUgUQAUgTAQgTQARgUAMgRQAMgQAFgLQAFgLgFgDQgEgEgHACQgHACgIAGQgJAFgJAIIgRARQgHAFgIACQgJADgIAAQgJABgJgBQgJgCgIgDQgFgBgDgDQgDgCgBgEQgBgEACgHQACgGAFgJQARgdAZgTQAZgUAdgFQASgDAPADQAQADANAGQANAHAKAJQAKAJAGAJQAIANACAMQACAMgCAMQgCALgGAMQgGAMgIAMQgIAOgNAOQgNAQgQAPQgPAQgRAOQgRAPgPAMQAOgDAPgBIAcgCQAIAAAFADQAGADAFAGIAIAMIAFANQADAGgCACQgDACgIABIgeADIgiAEIggAEIgbAFIgNACIgIgBg");
	this.shape_2.setTransform(947.4,223.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DFD1DD").s().p("AgRCcIgRgFQgJgCgIgEQgHgEgCgFQgDgGABgJQABgNADgXIAGgxIAKg1IAKg0IgMgGQgEgDgCgDQgCgDAAgDIADgJQAGgNAIgNIAQgXIAGgHQADgCADgBQADgBAEAAIAIACQALADAKAFQALAFAKAHQAKAGACAFQADAFgEAKIgLAmIgMAsIgMAvIgLAvIgJAsIgGAkQgCAGgDACIgEABIgIgBg");
	this.shape_3.setTransform(929.8,223);

	this.instance_47 = new lib.monster_2();
	this.instance_47.parent = this;
	this.instance_47.setTransform(1156,444,0.364,0.364);

	this.instance_48 = new lib.computer();
	this.instance_48.parent = this;
	this.instance_48.setTransform(831,191,0.387,0.387);

	this.instance_49 = new lib.player_1();
	this.instance_49.parent = this;
	this.instance_49.setTransform(831,271,0.387,0.387);

	this.instance_50 = new lib.bt_6x6();
	this.instance_50.parent = this;
	this.instance_50.setTransform(-318,96,0.393,0.393);

	this.instance_51 = new lib.CópiadebackgroundSQ();
	this.instance_51.parent = this;
	this.instance_51.setTransform(0,0,0.769,0.765);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_10},{t:this.instance},{t:this.instance_12},{t:this.instance_11,p:{scaleX:0.414,scaleY:0.414,x:15,y:14}}]},1).to({state:[{t:this.instance_51},{t:this.instance_50},{t:this.instance_11,p:{scaleX:0.387,scaleY:0.387,x:8,y:460}},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(515,161,1225,1467);
// library properties:
lib.properties = {
	id: '353FA121340FF249A1B937DCA64C9A74',
	width: 1024,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/modeloEscalas_atlas_.png?1682509009956", id:"modeloEscalas_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['353FA121340FF249A1B937DCA64C9A74'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;